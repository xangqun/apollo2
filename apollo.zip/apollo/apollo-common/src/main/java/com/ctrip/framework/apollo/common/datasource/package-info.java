/**
 * 携程内部的dal,第三方公司可替换实现
 */
package com.ctrip.framework.apollo.common.datasource;
