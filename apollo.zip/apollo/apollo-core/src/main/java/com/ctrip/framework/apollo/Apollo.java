package com.ctrip.framework.apollo;

/**
 * @author Jason Song(song_s@ctrip.com)
 */
public class Apollo {
  public final static String VERSION =
      "java-" + Apollo.class.getPackage().getImplementationVersion();
}
