DELETE FROM Item;
DELETE FROM Namespace;
DELETE FROM AppNamespace;
DELETE FROM Cluster;
DELETE FROM App;
DELETE FROM NamespaceLock;
DELETE FROM ServerConfig;

